(function(){
  function setDefaults(){
    try {
      window.__apiOrigin = window.location.origin;
    } catch(_) {
      window.__apiOrigin = '';
    }
    try {
      window.__uploadsBase = window.__apiOrigin;
    } catch(_) {
      window.__uploadsBase = '';
    }
  }

  function applyConfig(cfg){
    try {
      if (cfg && cfg.apiBase) {
        window.__apiOrigin = String(cfg.apiBase);
      }
      if (cfg && cfg.uploadsBase) {
        window.__uploadsBase = String(cfg.uploadsBase);
      } else {
        window.__uploadsBase = String(window.__apiOrigin || window.__uploadsBase || (window.location && window.location.origin) || '');
      }
    } catch(_) {}
  }

  function loadConfig(){
    try {
      if (typeof fetch === 'function') {
        fetch('/config', { method: 'GET', credentials: 'same-origin', cache: 'no-store' })
          .then(function(res){
            if (!res || !res.ok) return null;
            return res.json().catch(function(){ return null; });
          })
          .then(function(data){
            if (!data) return;
            applyConfig(data);
            scanImages();
          })
          .catch(function(){});
      }
    } catch(_) {}
  }

  setDefaults();
  loadConfig();

  // Compute base for non-API assets (uploads, images)
  try {
    window.__uploadsBase = String(window.__uploadsBase || window.__apiOrigin).replace(/\/?api\/?$/, '');
  } catch(_) {
    window.__uploadsBase = (window.location && window.location.origin) || '';
  }

  function normalizeUrl(u){
    try {
      var str = String(u || '');
      var m = str.match(/^https?:\/\/(localhost|127\.0\.0\.1):(3000|3003)(\/.*)$/i);
      if (m) {
        return (window.__uploadsBase || (window.location.origin)) + m[3];
      }
      return str;
    } catch(_) { return u; }
  }

  function normalizeImageEl(img){
    try {
      var src = img.getAttribute('src');
      var ns = normalizeUrl(src);
      if (ns && ns !== src) img.setAttribute('src', ns);
    } catch(_){}
  }

  function scanImages(){
    try {
      var imgs = document.images || document.querySelectorAll('img');
      for (var i=0;i<imgs.length;i++){ normalizeImageEl(imgs[i]); }
    } catch(_){}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scanImages);
  } else {
    scanImages();
  }

  // Observe DOM for dynamically added images
  try {
    var obs = new MutationObserver(function(muts){
      muts.forEach(function(m){
        (m.addedNodes || []).forEach(function(n){
          if (n && n.nodeType === 1) {
            if (n.tagName === 'IMG') { normalizeImageEl(n); }
            var nested = n.querySelectorAll ? n.querySelectorAll('img') : [];
            for (var i=0;i<nested.length;i++){ normalizeImageEl(nested[i]); }
          }
        });
      });
    });
    obs.observe(document.documentElement || document.body, { childList: true, subtree: true });
  } catch(_){}
})();
