// Shared admin sidebar injector with role-based visibility
(function(){
  function inject() {
    var sidebar = document.querySelector('aside.sidebar');
    if (!sidebar) return;
    sidebar.setAttribute('aria-label', 'Admin sidebar');

    var role = ((localStorage.getItem('userRole') || localStorage.getItem('role') || '') + '').toLowerCase();

    // Define menu items and allowed roles
    var items = [
      { href: 'admin.html',            label: 'Dashboard',           allowed: ['superadmin','admin','user_manager','listing_editor'] },
      { href: 'user-management.html',  label: 'User Management',     allowed: ['superadmin','user_manager'] },
      { href: 'listing-approval.html', label: 'Listing Approvals',   allowed: ['superadmin','user_manager'] },
      { href: 'create-listing.html',   label: 'Create New Listing',  allowed: ['superadmin','listing_editor','user_manager'] },
      { href: 'manage-all-listings.html', label: 'Manage All Listings', allowed: ['superadmin','listing_editor','user_manager'] },
      { href: 'category-management.html', label: 'Category Management', allowed: ['superadmin','listing_editor','user_manager'] },
      { href: 'tag-management.html',   label: 'Tag Management',      allowed: ['superadmin','listing_editor','user_manager'] },
      { href: 'model-management.html', label: 'Model Management',    allowed: ['superadmin','listing_editor'] },
      { href: 'role-management.html',  label: 'Role Management',     allowed: ['superadmin'] },
      { href: 'slider-management.html', label: 'Slider Management',  allowed: ['superadmin','listing_editor','user_manager'] },
      { href: 'blog-management.html',  label: 'Blog Management',     allowed: ['superadmin','user_manager'] },
      { href: 'setting.html',          label: 'Setting',             allowed: ['superadmin'] },
      { href: 'admin-messages.html',   label: 'Buyer Messages',      allowed: ['superadmin','user_manager'] },
      { href: 'invoice-intake.html',   label: 'Invoice Intake',      allowed: ['superadmin','user_manager'] },
      { href: 'review-management.html', label: 'Review Management',  allowed: ['superadmin'] }
    ];

    // If no role, show only Dashboard
    var filtered = items.filter(function(it){
      if (!role) return it.href === 'admin.html';
      return it.allowed.indexOf(role) !== -1;
    });

    var html = '<div class="sidebar-header">Main Menu</div><nav class="menu">' +
      filtered.map(function(it){
        return '<a href="' + it.href + '" title="' + it.label + '"><span class="icon"></span> ' + it.label + '</a>';
      }).join('') + '</nav>';

    sidebar.innerHTML = html;

    // Mark current page active
    try {
      var curr = (location.pathname.split('/').pop() || '').toLowerCase();
      var links = sidebar.querySelectorAll('nav.menu a');
      Array.prototype.forEach.call(links, function(a){
        var href = (a.getAttribute('href') || '').toLowerCase();
        if (href === curr || (!curr && href === 'admin.html')) {
          a.classList.add('active');
        }
      });
    } catch(e) {}
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inject);
  } else {
    inject();
  }
})();