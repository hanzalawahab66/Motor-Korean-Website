// Simple static file server for local preview
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const port = parseInt(process.argv[2], 10) || 5500;
const root = process.cwd();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function safeJoin(base, target){
  const resolvedPath = path.resolve(base, target.replace(/^[\\/]+/, ''));
  if (!resolvedPath.startsWith(path.resolve(base))) {
    return null; // path traversal attempt
  }
  return resolvedPath;
}

const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url);
  let pathname = decodeURIComponent(parsed.pathname || '/');
  if (pathname === '/') pathname = '/index.html';
  const filePath = safeJoin(root, pathname);
  if (!filePath) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    return res.end('Forbidden');
  }

  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Not Found');
    }
    const ext = path.extname(filePath).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type });
    const stream = fs.createReadStream(filePath);
    stream.on('error', () => {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Server Error');
    });
    stream.pipe(res);
  });
});

server.listen(port, () => {
  console.log(`[static-server] Serving ${root} on http://localhost:${port}/`);
});