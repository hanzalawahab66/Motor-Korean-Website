const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

// Use the same secret(s) as the backend server
const secret = process.env.JWT_SECRET || process.env.JWT_SECRET_ALT || 'dev-secret-change-me';

// Choose an existing approved buyer from users.json
const userId = 1761597392748;
const email = 'umarmarwat1@gmail.com';

const payload = {
  userId,
  email,
  role: 'buyer',
};

const token = jwt.sign(payload, secret, { expiresIn: '1d' });
console.log(token);

try {
  const outPath = path.join(__dirname, 'buyer.token.txt');
  fs.writeFileSync(outPath, token, 'utf8');
} catch (err) {
  // ignore file write errors in CI-like environments
}