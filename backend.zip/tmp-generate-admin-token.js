// Temporary helper to generate a compatible admin JWT using backend's dependencies
import jwt from 'jsonwebtoken';

const secret = process.env.JWT_SECRET_ALT || 'dev-secret-change-me';
const payload = {
  id: 1001,
  userId: 1001,
  email: 'admin@example.com',
  role: 'admin',
  iat: Math.floor(Date.now() / 1000),
  exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60)
};

const token = jwt.sign(payload, secret);
console.log(token);
console.error('Generated admin token. Set localStorage token and role=admin.');